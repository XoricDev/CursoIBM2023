"""
- Autor de la práctica: Jordi Mir Gomis, a.k.a Xoric Mee Go.

- Caso Práctico:
    - genera una matriz tamaño NxN.
    - rellenarla de números aleatorios comprendidos entre 0 y 9.
    - imprimir la matriz generada en pantalla.
    - sumar los elementos de cada fila y columna, (almacenar en dos listas).
    - imprimir en pantalla el resultado de la suma de cada fila y columna.
    - sugerencia:
        - incluir en el programa las excepciones necesarias.
        - incluir en el código los comentarios necesarios.
        - test unitarios necesarios.
"""
import random
import time

print("\n --- Caso Práctico - Prueba final de Formación, 'Curso Python Full Stack' ---- \n")
print(" Vamos a contruir una matriz llena de números de una sola cifra. Dicha matriz será cuadrada, entonces...")

contador = 0
while contador == 0:
    try:
        # Pedimos la dimensión de la matriz cuadrada por consola.
        dimensionMatriz = int(input(" Dame un solo número entero: "))
        print(f"\n Aquí tienes la matriz prometida de {dimensionMatriz}x{dimensionMatriz}. \n", )
        #print(dimensionMatriz) #test01 - dato introducido por teclado pra la generación de la matriz bidimensional cuadrada.
        contador +=1
    except(ValueError, IndexError, TypeError):
        print("Me parece que no va ha ser de esta, deberías introducir un NÚMERO ENTERO.")

# Declaramos la variable 'matriz'.
matrizCuadrada = []
#print(matriz) #test02 - comprobación de la declaración de la matriz.

# Creamos la matriz con el dato introducido por teclado en la variable 'dimensionMatriz'.
# primero iteramos las veces que nos indica 'dimensionMatriz' para generar filas.
for i in range(dimensionMatriz):
    filaMatriz = []
#    print(fila) #test03 - comprobación de la declaración de cada una de las iteraciones.

    #dentro de cada iteración anterior, recorremos la fila para llenarla de numeros de una sola cifra de manera aleatoria.
    for j in range(dimensionMatriz):
        filaMatriz.append(random.randint(0,9))
#        print(filaMatriz) #test04 - comprobamos cada una de las iteraciones y el contenido de cada una de las filas en cada una de ellas.
    matrizCuadrada.append(filaMatriz)
for filaMatriz in matrizCuadrada:
    print(filaMatriz)
time.sleep(1)

print("\n Y a continuación la suma de los elementos de cada una de las filas anteriormente mostradas en pantalla: \n")
time.sleep(2)

# Declaramos las listas que contendran el sumatorio de cada una de las filas y cada una de las columnas.
filasSumadas = []
columnasSumadas = []

#print(filasSumadas) #test05 - comprobación de la declaración de las lista sumatoria de filas.
#print(columnasSumadas) #test06 - comprobación de la declaración de las lista sumatoria de columnas.

# Para realizar el sumatorio de cada una de las filas e introducir el número en la lista anteriormente declarada.
for filaMatriz in matrizCuadrada:
    sumatorioFila = sum(filaMatriz)
    filasSumadas.append(sumatorioFila)

# Para realizar el sumatorio de cada una de las columnas e introducir el número en la lista anteriormente declarada.
for k in range(dimensionMatriz):
    sumatorioColumna = sum([filaMatriz[k] for filaMatriz in matrizCuadrada])
    columnasSumadas.append(sumatorioColumna)

# imprimir en pantalla la lista de los sumatorios de las filas.
print("El resultado de la suma de los elementos de cada una de las filas... \n")
print(filasSumadas)
time.sleep(1)

# imprimir en pantalla la lista de los sumtorios de las columnas.
print("\n Y el resultado de la suma de los elementos de cada una de las columnas... \n")
print(columnasSumadas)
time.sleep(1)

# despedida y cierre de la tarea y del curso realizado estos 2 últimos meses.
print("\n\n *** Esto es todo, gracias por vuestras enseñanzas gente de IBM *** \n\n")
time.sleep(1)
print("        - - - - - - - - - - - - - - - - - - - - - - - - - - -")
print("           --- by Jordi Mir Gomis, a.k.a Xoric Mee Go ---")
print("         - - - - - - - - - - - - - - - - - - - - - - - - - - \n\n\n")

"""
Me hubiera agradado poder dar más de mi y de todo lo que me habeis aportado en este curso,
pero me ha sido imposible por temas personales y laborales.
Este mundo de la programación me encanta, así que espero poder llegar a trabajar de ello,
más por la parte de disfrute que por la económica.
Espero volver a encontrarnos en futuros cursos, o quien sabe...
en futuros trabajos y poder colaborar con vosotros.
Gracias en especiala las dos caras visibles de este curso,
que a su vez me parece que tienen experiencia y conocimientos para parar un tren en este setor.
Espero que todo os vaya muy bien.
Salud!
        Xoric Mee Go.
"""